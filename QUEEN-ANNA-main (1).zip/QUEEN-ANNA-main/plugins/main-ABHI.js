let handler = async m => m.reply(`

≡  *𝚃𝙾𝙶𝙴 𝙸𝙽𝚄𝙼𝙰𝙺𝙸*   GROUPS
▢ Join Public Bot Group And Support
https://chat.whatsapp.com/BASoDcE8VL01jjVaraH1Ol
─────────────
▢ *Owner Telegram*
https://t.me/lawliet_kfx
 
▢ *YouTube*
https://youtube.com/@kenzo3146

▢ *Instagram*
https://instagram.com/lawliet.kfx

`.trim())
handler.help = ['Anna']
handler.tags = ['main']
handler.command = ['groups', 'Anna', 'Annagp', 'groupAnna'] 

export default handler

let handler = async m => m.reply(`

╭⭑⭑⭑★✪ 𝚀𝚄𝙴𝙴𝙽 𝙰𝙽𝙽𝙰 ✪★⭑⭑⭑
│ 📂 *BOT Name:* 𝚀𝚄𝙴𝙴𝙽 𝙰𝙽𝙽𝙰
│ 📝 *Description:* _I'm 𝚀𝚄𝙴𝙴𝙽 𝙰𝙽𝙽𝙰. A MultiDevice WhatsApp bot with rich features Created By 𝚃𝙾𝙶𝙴 𝙸𝙽𝚄𝙼𝙰𝙺𝙸_
│ 👤 *Owner:* 𝚃𝙾𝙶𝙴 𝙸𝙽𝚄𝙼𝙰𝙺𝙸
│ 🌐 *Channel:* https://whatsapp.com/channel/0029VaiuD4s4IBhI0fzbv40Z
╰━━━━━━━━━━━━━━━━╯
`.trim())
handler.help = ['channel']
handler.tags = ['main']
handler.command = ['xchannel', 'channel' ] 

export default handler

<p align="center">
<img src="https://raw.githubusercontent.com/toge012345/QUEEN-ANNA/main/ANNA.jpg?token=GHSAT0AAAAAACWTLQTAKIO46WHT6Q5MQYN4ZXBDOZQ" />
</p>
<h2>QUEEN ANNA</h2></h2>
<h3 align="center">A Simple WhatsApp Bot</h3>

<p align="center">
    <strong>QUEEN-ANNA-MD</strong> is a WhatsApp bot made to automate tasks on WhatsApp.
</p>

<p align="center">
    <a href='https://anna-web-woad.vercel.app/' target="_blank">
        <img alt='SESSION' src='https://img.shields.io/badge/Get%20Session%20ID-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=black&color=blue'/>
    </a>
     <a href="https://whatsapp.com/channel/0029VaiuD4s4IBhI0fzbv40Z">
        <img alt="WhatsApp" src="https://img.shields.io/badge/-Whatsapp%20Channel-green?style=for-the-badge&logo=whatsapp&logoColor=black"/>
    </a>
</p>

---

### a little about this bot
- ✔️ | **LOGO CMD** 
- ✔️ | **download songs** 
- ✔️ | **AI CHATBOT**
- ✔️ | **NSFW CMD**
- ✔️ | **Multi Device**   
---------

## Deployments Support

### HEROKU
[![Deploy on Heroku](https://img.shields.io/badge/Deploy%20on-Heroku-430098?style=for-the-badge&logo=heroku&logoColor=white)](https://www.heroku.com/deploy?template=https://github.com/toge012345/QUEEN-MIA-MD)

Deploy to Heroku for a quick and easy setup, [Create Account](https://signup.heroku.com/login) if you don't have one

---

### REPLIT
[![Deploy on Replit](https://img.shields.io/badge/Deploy%20on-Replit-0B0D0E?style=for-the-badge&logo=render&logoColor=white)](https://repl.it/github/toge012345/QUEEN-ANNA) 

you do not have a replit account created here [Create Account](https://replit.com/signup)

---

### RENDER
[![Deploy on Render](https://img.shields.io/badge/Deploy%20on-Render-003d2b?style=for-the-badge&logo=render&logoColor=white)](https://render.com/deploy?repo=https://github.com/toge012345/QUEEN-ANNA&env=SESSION_ID,BOT_INFO)

Use Render for deployment to take advantage of auto-scaling and global distribution. [Create Account](https://render.com/)

---

### RAILWAY
[![Deploy on Railway](https://img.shields.io/badge/Deploy%20on-Railway-0B0D0E?style=for-the-badge&logo=railway&logoColor=white)](https://railway.app/new/template?template=https://github.com/toge012345/QUEEN-ANNA&envs=SESSION_ID)


Deploy to Railway for a serverless experience and ease of use with GitHub integration. [Create Account](https://railway.app/)

---

### PANEL
[![Deploy on Panel](https://img.shields.io/badge/Deploy%20on-Panel-FF7139?style=for-the-badge&logo=pterodactyl&logoColor=white)](https://cpanel.net/)

Deploy using the Pterodactyl panel for an intuitive interface to manage multiple servers easily.


<img src="https://i.imgur.com/dBaSKWF.gif" height="90" width="100%">

<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Black+Ops+One&size=50&pause=1000&color=F70707&center=true&width=910&height=100&lines=QUEEN+ANNA" alt="Typing SVG" /></a>
  </p>
<img src="https://i.imgur.com/dBaSKWF.gif" height="90" width="100%">



# 🚨WARN🚨
𝐈 𝐀𝐌 𝐍𝐎𝐓 𝐑𝐄𝐒𝐏𝐎𝐍𝐒𝐈𝐁𝐋𝐄 𝐅𝐎𝐑 𝐘𝐎𝐔𝐑 𝐁𝐀𝐍𝐍𝐈𝐍𝐆 𝐎𝐍 𝐖𝐇𝐀𝐓𝐒𝐀𝐏𝐏 𝐀𝐓 𝐘𝐎𝐔𝐑 𝐎𝐖𝐍 𝐏𝐄𝐑𝐈𝐋.
𝐓𝐇𝐈𝐒 𝐁𝐎𝐓 𝐈𝐒 𝐄𝐍𝐂𝐑𝐘𝐏𝐓𝐄𝐃 𝐀𝐍𝐃 𝐏𝐑𝐎𝐓𝐄𝐂𝐓𝐄𝐃 𝐁𝐘 𝐓𝐇𝐄 𝐀𝐏𝐀𝐂𝐇𝐄-𝟐.𝟎 𝐋𝐈𝐂𝐄𝐍𝐒𝐄.
𝐓𝐇𝐈𝐒 𝐁𝐎𝐓 𝐈𝐒 𝐍𝐎𝐓 𝐀𝐍 𝐎𝐏𝐄𝐍 𝐒𝐎𝐔𝐑𝐂𝐄.
